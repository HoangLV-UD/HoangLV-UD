/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JDBC;

import Entity.NhanVien;

/**
 *
 * @author Pham Quoc Huy
 */
public class Auth {
    public static NhanVien user =  null;
    public static void clear(){
        Auth.user = null;
    }
    public static boolean isLogin(){
        return Auth.user != null;
    }
    public static boolean isManager(){
        return Auth.isLogin()&&user.isVai_tro();
    }
    public static NhanVien getUser() {
        return user;
    }

    public static void setUser(NhanVien user) {
        Auth.user = user;
    }
}
